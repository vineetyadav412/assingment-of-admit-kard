import { useState } from 'react';
import './Login.css';
import PhoneInput from 'react-phone-number-input'
import 'react-phone-number-input/style.css'
import OtpInput from 'react-otp-input';
import { useNavigate } from 'react-router-dom';

function EnterOtp(props){
  const {phoneNumber='', onClose, onSubmit} = props;
  const[otp, setOtp] = useState('');
  const[errorMsg, setErrorMsg] = useState('');

  const onVerify = async(event) => {
      event.preventDefault();
      const storedOtp = await localStorage.getItem('otp');
      if(otp){
        if(otp == storedOtp){
            onSubmit(otp);
        }else{
          setErrorMsg('⚠️ Invalid OTP')
        }
      }else{
        setErrorMsg('⚠️ Please enter OTP')
      }
  }

  return(
    <div class="modal" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div style={{height:'11em'}} />
      <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Verify Otp</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close" onClick={onClose}>
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <h6 class="modal-title" id="exampleModalLabel" style={{fontSize:'14px'}}>Please enter the OTP received on your number {phoneNumber}</h6>
            <div className="my-3">
            <div className=" d-flex justify-content-center">
              <OtpInput
                value={otp}
                onChange={(otp)=>setOtp(otp)}
                numInputs={4}
                isInputNum
                inputStyle={{
                  width: '2em',
                  borderTop:'none',
                  borderLeft:'none',
                  borderRight:'none',
                  borderBottom:'1px solid black'
                }}
                separator={<span>-</span>}
              />
            </div>
            <span className="text-left" style={{color:'gray',fontSize: '14px'}}>Hint: 1234</span>
            </div>
            <span className="text-danger text-left">{errorMsg}</span>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary dialog-btn" data-dismiss="modal" onClick={onClose}>Go Back</button>
            <button type="button" class="btn btn-primary dialog-btn" onClick={onVerify}>Done</button>
        </div>
        </div>
      </div>
    </div>
  )
}

const Login = (props) => {
  const navigate = useNavigate();
  const [value, setValue] = useState();
  const [validationError, setValidationError] = useState('');
  const [showOtpDialog, setShowOtpDialog] = useState(false);

  const sendOtp = async(event) => {
      event.preventDefault();
      if(value){
        if(value.length>10){
          setValidationError('');
          await localStorage.setItem('otp','1234');
          setShowOtpDialog(true);
        }else{
          setValidationError('⚠️ Invalid Phone number')
        }
      }else{
        setValidationError('⚠️ Please enter 10 digit Phone number')
      }
  }

  const handleSubmit= (hsValue) => {
      setShowOtpDialog(false);
      navigate('/verification_status');
  }

  return (
    <div class="container mt-5">
        {
           showOtpDialog? 
           <EnterOtp phoneNumber={value} onClose={()=>setShowOtpDialog(false)} onSubmit={handleSubmit}/>
           :
           null
        }
        <div class="row d-flex justify-content-center">
            <div class="col-md-6">
                <div class="card px-5 py-5" id="form1">
                    <div class="form-data">
                    <div class="success-data">
                        <div class="text-center d-flex flex-column"> 
                            <h2 class="text-center login-heading">Welcome back</h2> 
                            <h6 class="text-center login-heading">Please enter your Mobile number to login</h6> 
                        </div>
                    </div>
                    <div className="my-4">
                        <div class="forms-inputs"> 
                            <PhoneInput
                              placeholder="Enter phone number"
                              value={value}
                              onChange={setValue}
                              defaultCountry='IN'
                              rules={{ required: true }}
                            />
                        </div>
                        <span className="text-danger text-left">{validationError}</span>
                    </div>
                    <div class="mb-3">
                      <button class="btn btn-dark w-100" onClick={sendOtp}>Login</button>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
}

export default Login;
