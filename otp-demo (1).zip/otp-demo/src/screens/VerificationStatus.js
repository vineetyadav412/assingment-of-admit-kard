import logo from '../logo.svg';
import '../App.css';

function VerificationStatus() {
  return (
    <div class="container mt-5">
        <div class="row d-flex justify-content-center">
            <div class="col-md-6">
                <div class="card px-5 py-5" id="card">
                    <div class="form-data">
                    <div class="success-data">
                        <div class="text-center d-flex flex-column"> 
                            <h2 class="text-center login-heading" style={{color:'darkgreen', fontWeight:'600'}}>
                              Success 
                            </h2> 
                            <h6 class="text-center login-heading">Login successful</h6> 
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
}

export default VerificationStatus;
