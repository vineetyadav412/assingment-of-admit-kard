import './App.css';
import { Route, Routes } from 'react-router';
import Login from './screens/Login';
import VerificationStatus from './screens/VerificationStatus';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="verification_status" element={<VerificationStatus />} />
      </Routes>
    </div>
  );
}

export default App;
